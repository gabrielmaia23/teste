# inst-post-boot – publicação automática no Instagram (@simp.invest)

Publica imagem + legenda pela Instagram Graph API usando GitHub Actions (grátis).

## Configuração (uma vez)
1. Repositório **Public** (o Instagram precisa baixar a imagem pela URL).
2. Settings > Secrets and variables > Actions > **Repository secrets**:
   - `IG_TOKEN`: token de acesso (nunca coloque em arquivos do repositório)
   - `IG_USER_ID`: `17841441253956976`

## Publicar
Actions > **Publicar no Instagram** > Run workflow (imagem e legenda já vêm preenchidas).

## Novo post
Envie a imagem JPEG para `images/`, crie um `.txt` de legenda na raiz e rode o workflow com esses nomes.

Requisitos: conta Business/Creator ligada a uma Página do Facebook; token com `instagram_content_publish`.
